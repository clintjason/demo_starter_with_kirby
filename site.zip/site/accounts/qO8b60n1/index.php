<?php

return [
    'email' => 'ngassajason@gmail.com',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];