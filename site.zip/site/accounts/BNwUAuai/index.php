<?php

return [
    'email' => 'visitor@gmail.com',
    'language' => 'en',
    'name' => 'visitor',
    'role' => 'client'
];