Hey,

a new contact request has been submitted!

----
Sender Name: <?php echo $sender ?>

----
Email: <?php echo $email ?>

----
Text: <?php echo $text ?>